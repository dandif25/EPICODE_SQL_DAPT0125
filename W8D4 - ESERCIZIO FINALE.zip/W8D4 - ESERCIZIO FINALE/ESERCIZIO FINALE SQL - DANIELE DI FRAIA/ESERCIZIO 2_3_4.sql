-- ESERCIZIO.2 CREAZIONE SCHEMA + TABELLE
CREATE SCHEMA ToysGroup;
USE ToysGroup;
-- TABELLA CATEGORY
CREATE TABLE Category(
CategoryID INT
, CategoryName VARCHAR(50)
, CONSTRAINT PK_Category PRIMARY KEY (CategoryID)
);
-- TABELLA PRODUCT
CREATE TABLE Product(
ProductID INT
, ProductName VARCHAR(100)
, Price DECIMAL(10,2)
, CategoryID INT
, CONSTRAINT PK_Product PRIMARY KEY (ProductID)
, CONSTRAINT FK_CategoryID FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);
-- TABELLA REGION
CREATE TABLE Region(
RegionID INT
, RegionName VARCHAR(50)
, CONSTRAINT PK_Region PRIMARY KEY (RegionID)
);
-- TABELLA SALES
CREATE TABLE Sales(
SaleID INT
, Date DATE 
, Quantity INT
, ProductID INT
, RegionID INT
, CONSTRAINT PK_SaleID PRIMARY KEY (SaleID)
, CONSTRAINT FK_ProductID FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
, CONSTRAINT FK_RegionID FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);
-- ESERCIZIO.3
-- POPOLAMENTO TABELLA CATEGORY
INSERT INTO Category VALUES
(1, 'Action Figures')
, (2, 'Giochi da tavolo')
, (3, 'Video games');
-- POPOLAMENTO TABELLA PRODUCT
INSERT INTO Product VALUES
(101, 'Spiderman', 50.99, 1)
, (102, 'Superman', 69.90, 1)
, (103, 'Monopoly', 29.99, 2)
, (104, 'Scacchi', 12.99, 2)
, (105, 'FIFA 25', 34.99, 3)
, (106, 'Hogwarts Legacy', 33.99, 3);
-- POPOLAMENTO TABELLA REGION
INSERT INTO Region VALUES
(1, 'America')
, (2, 'Europa')
, (3, 'Asia')
, (4, 'Oceania');
-- POPOLAMENTO TABELLA SALES
INSERT INTO Sales VALUES
(201, '2025-03-01', 3, 101, 1)
, (202, '2025-03-02', 1, 104, 4)
, (203, '2025-03-03', 2, 102, 2)
, (204, '2025-03-04', 1, 105, 3)
, (205, '2025-03-05', 2, 103, 1)
, (206, '2025-03-06', 1, 106, 2);
-- ESERCIZIO.4 
/*1)Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query
per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).*/
-- CATEGORY
SELECT CategoryID, COUNT(*)
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;
-- PRODUCT
SELECT ProductID, COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;
-- REGION
SELECT RegionID, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;
-- SALES
SELECT SaleID, COUNT(*)
FROM Sales
GROUP BY SaleID
HAVING COUNT(*) > 1;
/*2)Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data,
il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita
e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita
o meno (>180 -> True, <= 180 -> False)*/
SELECT S.SaleID AS Codice_Documento
, S.Date AS Data
, P.ProductName AS Nome_Prodotto
, C.CategoryName AS Nome_Categoria
, R.RegionName AS Stato
,    CASE
        WHEN DATEDIFF(CURDATE(), S.Date) > 180 THEN TRUE
        ELSE FALSE
    END AS Oltre_180_giorni
FROM Sales AS S
INNER JOIN Product AS P
ON S.ProductID = P.ProductID
INNER JOIN Category AS C
ON P.CategoryID = C.CategoryID
INNER JOIN Region AS R
ON S.RegionID = R.RegionID;
/*3)Esporre l’elenco dei prodotti che hanno venduto, in totale,
una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito.
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano).
Nel result set devono comparire solo il codice prodotto e il totale venduto.*/
SELECT S.ProductID
, SUM(S.Quantity) AS Totale_Venduto
FROM Sales AS S
GROUP BY S.ProductID
HAVING SUM(S.Quantity) > (
SELECT AVG(Tot_Venduto_Per_Prodotto)
FROM(
SELECT SUM(S2.Quantity) AS Tot_Venduto_Per_Prodotto
FROM Sales AS S2
WHERE YEAR(S2.Date) = (
SELECT MAX(YEAR(Date)) FROM Sales)
GROUP BY S2.ProductID) AS Vendite_Ultimo_Anno);
-- 4)Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT S.ProductID
, YEAR(S.Date) AS Anno
, SUM(S.Quantity * P.Price) AS Fatturato_Totale
FROM Sales S
JOIN Product AS P
ON S.ProductID = P.ProductID
GROUP BY S.ProductID, YEAR(s.Date)
ORDER BY S.ProductID, Anno;
-- 5)Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT R.RegionName AS Stato
, YEAR(S.Date) AS Anno
, SUM(S.Quantity * P.Price) AS Fatturato_Totale
FROM Sales AS S
JOIN Product AS P
ON S.ProductID = P.ProductID
JOIN Region AS R
ON S.RegionID = R.RegionID
GROUP BY R.RegionName, YEAR(s.Date)
ORDER BY Anno ASC, Fatturato_Totale DESC;
-- 6)Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT C.CategoryName
, SUM(S.Quantity) AS Totale_Richiesto
FROM Sales AS S
JOIN Product AS P
ON S.ProductID = P.ProductID
JOIN Category AS C
ON P.CategoryID = C.CategoryID
GROUP BY C.CategoryName
ORDER BY Totale_Richiesto DESC
LIMIT 1;
/*7)Rispondere alla seguente domanda: quali sono i prodotti invenduti?
Proponi due approcci risolutivi differenti.*/
SELECT P.ProductID
, P.ProductName
FROM Product AS P
LEFT JOIN Sales AS S
ON P.ProductID = S.ProductID
WHERE S.SaleID IS NULL;
/*8)Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili
(codice prodotto, nome prodotto, nome categoria)*/
CREATE VIEW Views_Prodotti_Denormalizzata AS
SELECT P.ProductID AS Codice_Prodotto
, P.ProductName AS Nome_Prodotto
, C.CategoryName AS Nome_Categoria
FROM Product AS P
JOIN Category AS C
ON P.CategoryID = C.CategoryID;
/*
SELECT * 
FROM Views_Prodotti_Denormalizzata;
*/
-- 9)Creare una vista per le informazioni geografiche.
CREATE VIEW Views_Info_Geografiche AS
SELECT R.RegionID
, R.RegionName
, COUNT(S.SaleID) AS Numero_Transazioni
, SUM(S.Quantity) AS Totale_Quantità_Venduta
, SUM(S.Quantity * P.Price) AS Totale_Fatturato
, MAX(S.Date) AS Ultima_Data_Vendita
FROM Region AS R
LEFT JOIN Sales AS S
ON R.RegionID = S.RegionID
LEFT JOIN Product AS P
ON S.ProductID = P.ProductID
GROUP BY R.RegionID, R.RegionName;
/*
SELECT * 
FROM Views_Info_Geografiche;
*/